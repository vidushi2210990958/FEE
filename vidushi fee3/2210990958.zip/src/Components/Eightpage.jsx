import React from "react";

const Eight =() =>{
    return(
        <>
       <div className="background-4" id="c">
    <div className="row-3 group">
      <div className="about-cab">
        <p className="text-52">About cab Hub</p>
        <div className="rectangle-9" />
        <p className="text-53">
          Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
          Phasellus hendrerit, massa efficitur.Quisque sollicitudin feugiat
          risus, eu posuere ex euismod eu.
        </p>
        <img
          className="text-54"
          src="images/image_3.png"
          alt="            "
          width={132}
          height={20}
          title="            "
        />
      </div>
      <div className="download-2">
        <p className="download-3">Download</p>
        <div className="rectangle-9-copy" />
        <p className="text-55">
          Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
          Phasellus hendrerit, massa
        </p>
        <div className="row-7 group">
          <img
            className="text-57"
            src="images/image_2.png"
            alt=" "
            width={24}
            height={74}
            title=" "
          />
          <p className="text-56">
            Android Users
            <br />
            <span className="text-style">&nbsp;</span>
            <br />
            IOS Users
          </p>
        </div>
      </div>
      <div className="contact group">
        <p className="contact-2">Contact</p>
        <div className="rectangle-9-copy-2" />
        <div className="row-8 group">
          <img
            className="text-58"
            src="images/image.png"
            alt="   "
            width={17}
            height={171}
            title="   "
          />
          <p className="text-59">
            +123, Main Street, Your City,
            <br />
            New York, USA 789456
            <br />
            <span className="text-style-2">&nbsp;</span>
            <br />
            +123 4567 8900
            <br />
            <span className="text-style-2">&nbsp;</span>
            <br />
            free@psdfreebies.com
            <br />
            <span className="text-style-2">&nbsp;</span>
            <br />
            www.psdfreebies.com
          </p>
        </div>
      </div>
    </div>
    <div className="bottam">
      <div className="l-constrained-6">Copyright © 2015 PSDfreebies.com</div>
    </div>
  </div>
        </>
    )
}
export default Eight