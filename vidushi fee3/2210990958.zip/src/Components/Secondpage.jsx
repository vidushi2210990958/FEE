import React from "react";

const Second =() =>{
    return(
        <>
         <div className="group-4" id="o">
    <div className="l-constrained-4 group">
      <div className="about">
        <p className="text-5">BEst In City</p>
        <p className="text-6">
          Trusted Cab Servies
          <br />
          in New York
        </p>
        <p className="text-7">
          Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
          Phasellus hendrerit, massa efficitur dapibus pulvinar, sapien eros
          sodales ante, euismod aliquet nulla metus a mauris.Quisque
          sollicitudin feugiat risus, eu posuere ex euismod eu. Phasellus
          hendrerit, massa efficitur dapibus pulvinar, sapien eros sodales ante,
          euismod aliquet nulla metus a mauris.
        </p>
        <div className="rounded-rectangle-1-copy-4-holder">
          <img
            className="text-8"
            src="images/read_more_2.png"
            alt="Read More"
            width={100}
            height={21}
            title="Read More"
          />
        </div>
      </div>
      <div className="booking-form">
        <p className="text-9">
          Book a <span className="colorffc61a">Cab</span>
        </p>
        <div className="row-12 group">
          <div className="wrapper-11">
            <img
              className="text-10"
              src="images/name_when_start_choose_ve.png"
              alt="Name When Start Choose Vehicle"
              width={135}
              height={230}
              title="Name When Start Choose Vehicle"
            />
            <div className="rectangle-2" />
            <div className="rectangle-2-copy-2" />
            <div className="rectangle-2-copy-3" />
          </div>
          <div className="col-21">
            <div className="wrapper-13">
              <img
                className="text-11"
                src="images/phone_time_end.png"
                alt="Phone Time End"
                width={57}
                height={160}
                title="Phone Time End"
              />
              <div className="rectangle-2-copy" />
              <div className="rectangle-2-copy-2-2" />
            </div>
            <div className="rectangle-2-copy-3-2" />
          </div>
        </div>
        <div className="rectangle-2-copy-4" />
        <div className="rounded-rectangle-1-copy-5-holder">
          <img
            className="submit"
            src="images/submit.png"
            alt="Submit"
            width={67}
            height={21}
            title="Submit"
          />
        </div>
      </div>
    </div>
  </div>
        </>
    )
}
export default Second