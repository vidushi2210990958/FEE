import React from "react";

const Fifth =() =>{
    return(
        <>
       <div className="group-10" id="b">
    <div className="heading-3">
      <p className="download">Download</p>
      <p className="text-40">Best Cab Servies</p>
    </div>
    <div className="row group">
      <div className="side-copy">
        <p className="text-41">
          Downlaod the Cab voucher app free!
          <br />
          Get Exciting New Offers
        </p>
        <p className="text-42">
          Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
          Phasellus hendrerit, massa efficitur.
        </p>
        <div className="row-5 group">
          <img
            className="rounded-rectangle-2"
            src="images/rounded_rectangle_2.png"
            alt=""
          />
          <img
            className="rounded-rectangle-2-copy"
            src="images/rounded_rectangle_2_copy.png"
            alt=""
          />
        </div>
      </div>
      <img
        className="place-app-screen-here"
        src="images/place_app_screen_here.png"
        alt=""
        width={386}
        height={466}
      />
    </div>
  </div>
        </>
    )
}
export default Fifth