import React from "react";

const Sixth =() =>{
    return(
        <>
        <div className="background-3">
    <div className="l-constrained-2">
      <div className="heading-4">
        <p className="text-43">Happy Client's</p>
        <p className="testimonials">Testimonials</p>
      </div>
      <div className="row-4 match-height group">
        <div className="group-11">
          <p className="text-44">
            Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
            Phasellus hendrerit, massa efficitur.Quisque sollicitudin feugiat
            risus.
          </p>
          <div className="row-11 group">
            <img className="ellipse-1" src="images/ellipse_1.png" alt="" />
            <div className="col-18">
              <p className="text-45">John Doe</p>
              <p className="text-46">Business man</p>
            </div>
          </div>
        </div>
        <div className="group-12 group">
          <p className="text-47">
            Quisque sollicitudin feugiat risus, eu posuere ex euismod eu.
            Phasellus hendrerit, massa efficitur.Quisque sollicitudin feugiat
            risus.
          </p>
          <div className="row-10 group">
            <img
              className="ellipse-1-copy"
              src="images/ellipse_1_copy.png"
              alt=""
            />
            <div className="col-17">
              <p className="text-48">John Doe</p>
              <p className="text-49">Business man</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
        </>
    )
}
export default Sixth